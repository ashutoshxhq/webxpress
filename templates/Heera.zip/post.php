<?php
include_once '../admin/dbconnect.php';
$master="master";
$query = $DBcon->query("SELECT * FROM users WHERE type='$master'");
$userRow=$query->fetch_array();
$about = $userRow['about'];    
$website = $userRow['website'];
$name = $userRow['name'];
$email = $userRow['email'];    
$about = $userRow['about'];    
$fb = $userRow['facebook'];    
$tr = $userRow['twitter'];    

$id = $_GET['id'];
if(!isset($id))
{
 header("Location: index.php");
}
$querry = $DBcon->query("SELECT * FROM post WHERE post_id='$id'");
$post=$querry->fetch_array();
$topic=$post['topic'];
$data=$post['data'];
$time=$post['time'];
$author=$post['author'];


?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?php echo $website; ?></title>

	<meta name="description" content="<?php echo $website; ?>" >

	<meta name="author" content="Jewel Theme">

	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->

	<!-- Bootstrap  -->
	<link href="assets/css/bootstrap.min.css" rel="stylesheet">

	<!-- icon fonts font Awesome -->
	<link href="assets/css/font-awesome.min.css" rel="stylesheet">

	<!-- Import Magnific Pop Up Styles -->
	<link rel="stylesheet" href="assets/css/magnific-popup.css">

	<!-- Import Custom Styles -->
	<link href="assets/css/style.css" rel="stylesheet">

	<!-- Import Animate Styles -->
	<link href="assets/css/animate.min.css" rel="stylesheet">

	<!-- Import owl.carousel Styles -->
	<link href="assets/css/owl.carousel.css" rel="stylesheet">

	<!-- Import Custom Responsive Styles -->
	<link href="assets/css/responsive.css" rel="stylesheet">

	
	<!--[if IE]>
  		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  		<![endif]-->

  	</head>
  	<body class="header-fixed-top">

  		<div id="page-top" class="page-top"></div><!-- /.page-top -->

  		<section id="top-contact" class="top-contact">
  			<div class="container">
  				<div class="row">
  					<div class="col-sm-8 pull-left">
  						<ul class="contact-list">
  							<li>
  								<a class="site-name" href="#">
  									<span class="top-icon"><i class="fa fa-link"></i></span>
  									<?php echo $website; ?>
  								</a>
  							</li>
  							<li>
  								<a class="info" href="#">
  									<span class="top-icon"><i class="fa fa-envelope"></i></span>
  									<?php echo $email; ?>
  								</a>
  							</li>
  						</ul>
  					</div>

  					<div class="col-sm-4 pull-right">
  						<div class="top-social">
  							<ul>
  								<li>
  									<a href="http://<?php echo $fb; ?>" class="top-icon fa fa-facebook"></a>
  								</li>
  								<li>
  									<a href="http://<?php echo $tr; ?>" class="top-icon fa fa-twitter"></a>
  								</li>
  							</ul>
  						</div>
  					</div>
  				</div><!-- /.row -->
  			</div><!-- /.container -->
  		</section><!-- /#top-contact -->


  		<header id="main-menu" class="main-menu">
  			<div class="container">
  				<div class="row">
  					<div class="col-sm-7">
  						<div class="navbar-header">
  							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#menu">
  								<i class="fa fa-bars"></i>
  							</button>
                <div class="menu-logo">
                  <a href="./"><img src="images/logo.png" alt="menu Logo"></a>
                </div><!-- /.menu-logo -->
              </div>
              <nav id="menu" class="menu collapse navbar-collapse">
               <ul id="headernavigation" class="menu-list nav navbar-nav">
                 <li><a href="index.php">Home</a></li>
            <?php

$sql = "SELECT * FROM page";
$result = $DBcon->query($sql);

if ($result->num_rows >0) {
    while($row = $result->fetch_assoc())  {
     echo '<li><a href="page.php?id='.$row["page_id"].'">'.$row["topic"].'</a></li>';
    }

} 
?>
     
              </ul><!-- /.menu-list -->
            </nav><!-- /.menu-list -->
          </div>

          <div class="col-sm-5">
            <div class="menu-search pull-right">
             <form role="search" class="search-form" action="search.php" method="post">
              <input class="search-field" type="text" name="search" id="s" placeholder="Search Here" required>
              <button class="btn search-btn" name="submit" type="submit"><i class="fa fa-search"></i></button>
            </form><!-- /.search-form -->
          </div><!-- /.menu-search -->
        </div>
      </div><!-- /.row -->
    </div><!-- /.container -->
  </header><!-- /#main-menu -->





      <section id="main-content" class="main-content blog-post-singgle-page">
        <div class="container">
          <div class="row">
            <div class="col-sm-8">
              <div id="blog-post-content" class="blog-post-content">
                <article class="post type-post">
                  <div class="post-top">
                    <div class="post-thumbnail">
                      <img class="img-responsive" src="../media/post_img/<?php echo $topic; ?>.jpg" alt="post Image">
                    </div><!-- /.post-thumbnail -->  
                    <div class="post-meta">
                      <div class="entry-meta">
                        <div class="author-avatar">
                          <img src="images/author/1.jpg" alt="Author Image">
                        </div><!-- /.author-avatar -->
                        <div class="entry-meta-content">
                          <span class="author-name">
                            <a href="#"><?php echo $author; ?></a>
                          </span>
                          <span class="entry-date">
                            <time datetime="2015-01-15"><?php echo $time; ?></time>
                          </span>
                        </div><!-- /.meta-content -->
                      </div><!-- /.entry-meta -->
                    </div><!-- /.post-meta -->
                  </div><!-- /.post-top -->
                  <div class="post-content">
                    <h2 class="entry-title"><a href="#"><?php echo $topic; ?></a></h2>
                     <?php echo $data; ?>
                  </div><!-- /.post-content -->

                  <div id="comments" class="comments">
                    <div class="comments-area">
                      <div id="leave-comment" class="clearfix leave-comment">
                        <h3 class="title"><span class="title-icon ti-comment-alt"></span>Leave A Reply</h3>
                        <div id="respond">
                          <form method="post" action="comments.php" id="commentform" class="commentform">
                            <input id="author" class="name" name="name" type="text" placeholder="Name*" value="" required>
                            <input id="email" class="email" name="email" type="email" placeholder="Email*" value="" required>
                            <input id="url" class="url" name="topic" type="text" placeholder="Subject*" value="" required>
                            <input class="form-control" id="exampleInputEmail1" name="post" value="<?php echo $topic;?>" type="hidden">
					        <textarea id="comment" class="comment" name="data" placeholder="Comment" rows="4" required></textarea>
                            <button name="submit" class="submit-btn" type="submit" id="submit"><span class="ti-shift-right"></span>Submit</button>
                          </form><!-- /#commentform -->
                        </div><!-- /#respond -->
                      </div><!-- /#leave-comment -->
                    </div><!-- /.comment-area -->
                  </div><!-- /#comment -->
                </article>
              </div>
            </div>
            <div class="col-sm-4">
              <div id="blog-sidebar" class="blog-sidebar widget-area" role="complementary">
                <div class="sidebar-content">

                 <aside class="widget widget_text">
                                <h3 class="widget-title">About</h3>
                                <div class="tiny-border"></div>                                         
                                <div class="textwidget">
                                    <p><?php echo $about; ?>
                                    </p>                              
                                </div>
                            </aside>  
                            
                            <?php

$sql = "SELECT * FROM sidebar ORDER By sidebar_id DESC LIMIT 0,10";
$result = $DBcon->query($sql);

if ($result->num_rows >0) {
    while($row = $result->fetch_assoc())  {

$topic=$row["topic"];
$data=$row["data"];


echo '<aside class="widget widget_text">
                                <h3 class="widget-title">'.$topic.'</h3>
                                <div class="tiny-border"></div>                                         
                                <div class="textwidget">
                                    <p>'.$data.'
                                    </p>                              
                                </div>
                            </aside>';

    }

} 
?>

             
                    </div><!-- /.sidebar-content -->
                  </div><!-- /#sidebar -->
                </div>
              </div>
            </div><!-- /.container -->
          </section><!-- /#main-content -->








<footer>
  <div id="footer-bottom" class="footer-bottom text-center">
    <div class="container">
      <div id="copyright" class="copyright">
        &copy;  <?php echo $website; ?>  2015 - Designed &amp; Developed by <a href="http://soxpress.com">Soxpress</a>
      </div><!-- /#copyright -->
    </div>
  </div><!-- /#footer-bottom -->
</footer>


          <div id="scroll-to-top" class="scroll-to-top">
           <span>
            <i class="fa fa-chevron-up"></i>    
          </span>
        </div><!-- /#scroll-to-top -->



        <!-- Include modernizr-2.8.3.min.js -->
        <script src="assets/js/modernizr-2.8.3.min.js"></script>

        <!-- Include jquery.min.js plugin -->
        <script src="assets/js/jquery-2.1.0.min.js"></script>

        <!-- Javascript Plugins  -->
        <script src="assets/js/plugins.js"></script>

        <!-- Custom Functions  -->
        <script src="assets/js/functions.js"></script>

        <script src="assets/js/wow.min.js"></script>

      </body>
      </html>

