<?php
include_once '../admin/dbconnect.php';
$master="master";
$query = $DBcon->query("SELECT * FROM users WHERE type='$master'");
$userRow=$query->fetch_array();
$about = $userRow['about'];    
$website = $userRow['website'];
$name = $userRow['name'];

$id = $_GET['id'];
if(!isset($id))
{
 header("Location: index.php");
}
$querry = $DBcon->query("SELECT * FROM page WHERE page_id='$id'");
$post=$querry->fetch_array();
$topic=$post['topic'];
$data=$post['data'];
$time=$post['time'];
$author=$post['author'];

?>
<!DOCTYPE html>
<html>
<head>
<title><?php echo $website; ?></title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/css/font.css">
<link rel="stylesheet" href="assets/css/animate.css">
<link rel="stylesheet" href="assets/css/structure.css">
<!--[if lt IE 9]>
<script src="assets/js/html5shiv.min.js"></script>
<script src="assets/js/respond.min.js"></script>
<![endif]-->
</head>
<body>
<div id="preloader">
  <div id="status">&nbsp;</div>
</div>
<a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
<header id="header">
  <div class="container">
    <nav class="navbar navbar-default" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
          <a class="navbar-brand" href="index.php"><span><?php echo $website; ?></span></a> </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav custom_nav">
            <li class=""><a href="index.php">Home</a></li>
            <?php

$sql = "SELECT * FROM page";
$result = $DBcon->query($sql);

if ($result->num_rows >0) {
    while($row = $result->fetch_assoc())  {
     echo '<li><a href="page.php?id='.$row["page_id"].'">'.$row["topic"].'</a></li>';
    }

} 
?>
          </ul>
        </div>
      </div>
    </nav>
    <form action="search.php" id="searchForm" method="post">
      <input type="text" name="search" placeholder="Search...">
      <input type="submit" name="submit" value="">
    </form>
  </div>
</header>
<section id="contentbody">
  <div class="container">
    <div class="row">
      <div class=" col-sm-12" style="margin-left:5%;width:60%;">
        <div class="row">
          <div class="leftbar_content">
            <h2>The New Stuff</h2>
            <div class="singlepost_area">
              <div class="singlepost_content"> Author: <?php echo $author; ?>, Published on:<?php echo $time; ?> <span class="stuff_date">Page <strong><?php echo $id; ?></strong></span>
                <h2><a href="page.php?id='.$id.'"><?php echo $topic; ?></a></h2>
                <img class="img-center" style="width:100%;" src="../media/page_img/<?php echo $topic; ?>.jpg" alt="">
                <?php echo $data; ?>
                <div class="author"> <a href="#"><img src="images/avatar3.png" alt=""></a>
                  <div class="author_details">
                    <h3><a href="#"><?php echo $name; ?>(About Author)</a></h3>
                    <?php echo $about; ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    <div class="col-sm-6" style="margin-left:10%;width:20%;">
        <div class="row">
          <div class="middlebar_content">
            <h2 class="yellow_bg">What's Hot</h2>
            <div class="middlebar_content_inner wow fadeInUp">
              <ul class="middlebar_nav">
                <?php

$sql = "SELECT * FROM post ORDER By post_id DESC LIMIT 0,10";
$result = $DBcon->query($sql);

if ($result->num_rows >0) {
    while($row = $result->fetch_assoc())  {

$topic=$row["topic"];
$id=$row["post_id"];


echo '<li> <a class="mbar_thubnail" href="post.php?id='.$id.'"><img style="width:100%;" src="../media/post_img/'.$topic.'.jpg" alt=""></a> <a class="mbar_title" href="post.php?id='.$id.'">'.$topic.'</a> </li>';

    }

} 
?>
</ul>
            </div>
          </div>
          
          
          
          <?php

$sql = "SELECT * FROM sidebar ORDER By sidebar_id DESC LIMIT 0,10";
$result = $DBcon->query($sql);

if ($result->num_rows >0) {
    while($row = $result->fetch_assoc())  {

$topic=$row["topic"];
$data=$row["data"];


echo '<div class="middlebar_content">
            <h2 class="yellow_bg">'.$topic.'</h2>
            <div class="middlebar_content_inner wow fadeInUp">
              <ul class="middlebar_nav">
            '.$data.'
              </ul>
            </div>
          </div>';

    }

} 
?>
          
          
        </div>
      </div>
      </div>
  </div>
</section>
<footer id="footer">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="footer_inner">
          <p class="pull-left">Copyright &copy; 2016 <?php echo $website; ?></p>
          <p class="pull-right">Developed By Webxpress</p>
        </div>
      </div>
    </div>
  </div>
</footer>
<script src="assets/js/jquery.min.js"></script> 
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/wow.min.js"></script> 
<script src="assets/js/custom.js"></script>
</body>
</html>
