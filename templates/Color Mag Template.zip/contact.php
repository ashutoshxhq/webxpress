<?php
session_start();

include_once '../admin/dbconnect.php';

if(isset($_POST['submit'])) {
 
 $name = strip_tags($_POST['name']);
 $topic = strip_tags($_POST['topic']);
 $post = strip_tags($_POST['post']);
 $email = strip_tags($_POST['email']);
 $data = $_POST['data'];
 $query = "INSERT INTO comment(name,data,email,topic,post) VALUES('$name','$data','$email','$topic','$post')";

  if ($DBcon->query($query)) {
 
  header("Location: index.php");
  
}
}
?>
