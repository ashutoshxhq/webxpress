<?php
session_start();

include_once '../admin/dbconnect.php';

if(isset($_POST['submit'])) {
 
 $email = strip_tags($_POST['email']);
 $query = "INSERT INTO users(email) VALUES('$email')";

  if ($DBcon->query($query)) {
 
  header("Location: index.php");
  
}
}
?>
