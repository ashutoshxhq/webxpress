<?php
include_once '../admin/dbconnect.php';
$master="master";
$query = $DBcon->query("SELECT * FROM users WHERE type='$master'");
$userRow=$query->fetch_array();
$about = $userRow['about'];    
$website = $userRow['website'];    
$email = $userRow['email'];    
$about = $userRow['about'];    
$fb = $userRow['facebook'];    
$tr = $userRow['twitter'];    

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?php echo $website; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Favicons
    ================================================== -->
    <link rel="icon" href="images/favicon.png" type="image/x-icon">    
   
    <!-- LOAD CSS FILES -->    
    <link href="style.css" rel="stylesheet" type="text/css">  

    <!-- color scheme -->
    <link rel="stylesheet" href="switcher/demo.css" type="text/css">
    <link rel="stylesheet" href="switcher/colors/blue.css" type="text/css" id="colors">      
</head>

<body>
    <!-- Preload images start //-->
    <div class="images-preloader" id="images-preloader">
        <div class="spinner">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
        </div>
    </div>
    <!-- Preload images end //-->
    
    <div id="wrapper">

        <!-- header begin -->
        <header class="site-header-1 site-header">
            <!-- Main bar start -->
            <div id="sticked-menu" class="main-bar">
                <div class="container">                
                    <div class="row">                    
                        <div class="col-md-12">

                            <!-- logo begin -->
                            <div id="logo" class="pull-left">                            
                                <a href="index.php">
                                    <h3 style="padding:20px;"><?php echo $website; ?></h3>
                                </a>
                            </div>
                            <!-- logo close -->

                            <!-- btn-mobile menu begin -->
                            <a id="show-mobile-menu" class="btn-mobile-menu hidden-lg hidden-md"><i class="fa fa-bars"></i></a>
                            <!-- btn-mobile menu close -->  

                            <!-- mobile menu begin -->
                            <nav id="mobile-menu" class="site-mobile-menu hidden-lg hidden-md">
                                <ul></ul>
                            </nav>  
                            <!-- mobile menu close -->                        

                            <!-- desktop menu begin -->
                            <nav id="desktop-menu" class="site-desktop-menu hidden-xs hidden-sm">
                                <ul class="clearfix">
                                        <li><a href="index.php">Home</a></li>
            <?php

$sql = "SELECT * FROM page";
$result = $DBcon->query($sql);

if ($result->num_rows >0) {
    while($row = $result->fetch_assoc())  {
     echo '<li><a href="page.php?id='.$row["page_id"].'">'.$row["topic"].'</a></li>';
    }

} 
?>
                                    </ul>
                            </nav>
                            <!-- desktop menu close -->
                            
                            <!-- Header Group Button Right begin -->
                            <div class="header-buttons pull-right hidden-xs hidden-sm">
                                
                                <div class="header-contact">
                                    <ul class="clearfix">
                                        <li class="phone"><i class="fa fa-envelope-o"></i> <span><?php echo $email; ?></span></li>
                                        <li class="border-line">|</li>
                                    </ul>
                                </div>

                                <!-- Button Modal popup searchbox -->
                                <div class="search-button">
                                    <!-- Trigger the modal with a button -->
                                    <a href="" data-toggle="modal" data-target="#myModal"><i class="fa fa-search"></i></a>                                                                        
                                </div>

                                <div class="navright-button">
                                    <a href="" id="btn-offcanvas-menu"><i class="fa fa-bars"></i></a>                                    
                                </div> 

                            </div>
                            <!-- Header Group Button Right close -->

                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- header close -->
        <div class="gray-line-2"></div>

        <!-- Modal Search begin -->
        <div id="myModal" class="modal fade" role="dialog">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <div class="modal-dialog myModal-search">
            <!-- Modal content-->
            <div class="modal-content">                                        
                <div class="modal-body">
                    <form action="search.php" method="post" class="search-form">
                        <input type="search" name="search" class="search-field" placeholder="Search here..." value="" title="" />
                        <button type="submit" name="submit" class="search-submit"><i class="fa fa-search"></i></button>
                    </form>
                </div>
            </div>
          </div>
        </div>
        <!-- Modal Search close -->

        <!-- Menu OffCanvas right begin -->
        <div class="navright-button hidden-sm">
            <div class="compact-menu-canvas" id="offcanvas-menu">
                <h3>menu</h3><a id="btn-close-canvasmenu"><i class="fa fa-close"></i></a>
                <nav>
                  <ul class="clearfix">
                        <li><a href="index.php">Home</a></li>
            <?php

$sql = "SELECT * FROM page";
$result = $DBcon->query($sql);

if ($result->num_rows >0) {
    while($row = $result->fetch_assoc())  {
     echo '<li><a href="page.php?id='.$row["page_id"].'">'.$row["topic"].'</a></li>';
    }

} 
?>
                    </ul>                
                </nav>
            </div>
        </div> 
        <!-- Menu OffCanvas right close -->

   <section id="sub-header-4" class="subheader no-padding clearfix">
                <div class="subheader-top">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12" style="text-align:right;">
                                <h1>Blog</h1>
                            </div>
                        </div><!-- End Row -->
                    </div><!-- End container --> 
                </div>
                <div class="subheader-bottom">
                   <div class="container">
                      <div class="row">
                         <div class="col-md-12">
                             <ul class="breadcrumbs">
                                <li><a href="index.html"> <i aria-hidden="true" class="fa fa-home"></i> Home</a></li>
                                <li class="active">Our Posts</li>
                              </ul>
                         </div><!--  End col -->
                      </div> <!-- End Row -->
                   </div><!-- End container -->
                </div> 
                <div class="breadcrumbs-line"></div>            
            </section>     
        
        <div id="content">
            <div class="container">
                <div class="row"> 
                    <div class="col-md-9">
                        <div class="blog-list">
                            <!-- post begin -->
                            <?php

$sql = "SELECT * FROM post ORDER By post_id DESC";
$result = $DBcon->query($sql);

if ($result->num_rows >0) {
    while($row = $result->fetch_assoc())  {
     
$dat=strip_tags($row["data"]);
$data=  substr(".$dat.",'0','500')."...";  
$topic=$row["topic"];
$time=$row["time"];
$author=$row["author"];
$id=$row["post_id"];

echo '<article>
                                <div class="post-media">
                                    <img alt="" src="../media/post_img/'.$topic.'.jpg" class="img-responsive">
                                    <div class="post-date">
                                        <span class="date-day">'.$id.'</span>
                                        <span class="date-month">Post</span>
                                    </div>
                                </div>
                                <div class="post-content">
                                    <div class="post-title">
                                        <h5><a href="post.php?id='.$id.'">'.$topic.'</a></h5>
                                    </div>
                                    <div class="post-metadata">
                                        <span class="byline">
                                            <i class="fa fa-user"></i>
                                            <a href="#">'.$author.'</a>
                                        </span>
                                        <span class="cat-links">                                            
                                            <i class="fa fa-folder-open"></i>
                                            <a href="#">Published Date: '.$time.'</a>
                                        </span>
                                    </div>
                                    <div class="post-entry">
                                        '.$data.'<a class="btn btn-border" href="post.php?id='.$id.'">Read more</a></p>
                                    </div>
                                </div>
                            </article>';
    }

} 
?>
                            <!-- post close -->
                        </div>

                    </div>
                    <div class="col-md-3">
                        <div class="main-sidebar">
                            <aside class="widget widget_search">
                                <form action="search.php" method="post" class="search-form" role="search">
                                    <input type="search" name="search" value="" placeholder="Search …" class="search-field">   
                                    <button class="search-submit" name="submit" type="submit"><i class="fa fa-search"></i></button>
                                </form>
                            </aside> 
                            <aside class="widget widget_text">
                                <h3 class="widget-title">About</h3>
                                <div class="tiny-border"></div>                                         
                                <div class="textwidget">
                                    <p><?php echo $about; ?>
                                    </p>                              
                                </div>
                            </aside>
                            
                            <?php

$sql = "SELECT * FROM sidebar ORDER By sidebar_id DESC LIMIT 0,10";
$result = $DBcon->query($sql);

if ($result->num_rows >0) {
    while($row = $result->fetch_assoc())  {

$topic=$row["topic"];
$data=$row["data"];


echo '<aside class="widget widget_text">
                                <h3 class="widget-title">'.$topic.'</h3>
                                <div class="tiny-border"></div>                                         
                                <div class="textwidget">
                                    <p>'.$data.'
                                    </p>                              
                                </div>
                            </aside>';

    }

} 
?>
                                         
                        </div>                        
                    </div>
                </div>
            </div> 
        </div>
        <!-- content close -->
       
        <!-- footer begin -->
        <footer class="footer-1 bg-color-1">

            <!-- main footer begin -->
            <div class="main-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="compact-widget">                                                
                                <div class="widget-inner">
                                   <h3 class="widget-title">About</h3> 
                                    <p><?php echo $about; ?></p>
                                    <div class="social-icons clearfix">
                                    <a href="http://<?php echo $fb; ?>" class="facebook" ><i class="fa fa-facebook"></i></a>
                                        <a href="http://<?php echo $tr; ?>" class="twitter" ><i class="fa fa-twitter"></i></a>
                                        </div>
                                </div>    
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="compact-widget">
                                <h3 class="widget-title">Pages</h3> 
                                <div class="widget-inner">
                                    <ul>
                                        <?php

$sql = "SELECT * FROM page";
$result = $DBcon->query($sql);

if ($result->num_rows >0) {
    while($row = $result->fetch_assoc())  {
     echo '<li><a href="page.php?id='.$row["page_id"].'">'.$row["topic"].'</a></li>';
    }

} 
?>
                                    </ul>
                                </div>                                                   
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="compact-widget">
                                <h3 class="widget-title">Soxpress</h3>
                                <div class="widget-inner">
                                    <p>This website has been created by soxpress <br>
                                    Create Yourself a website now</p>
                                    <p><a href="http://www.soxpress.com" class="btn btn-success">Create</a></p>
                                    
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="compact-widget">
                                <h3 class="widget-title">Newsletter</h3>
                                <div class="widget-inner">
                                    <div class="newsletter newsletter-widget">
                                        <p>Stay informed about our news and events</p>
                                        <form action="newsletters.php" method="post">
                                            <p><input class="newsletter-email" type="email" name="email" placeholder="Your email"><i class="fa fa-envelope-o"></i></p>
                                            <p><input class="newsletter-submit" name="submit" type="submit" value="Subscribe"></p>
                                        </form>
                                    </div>                                
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>            
            <!-- main footer close -->

            <!-- sub footer begin -->
            <div class="sub-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <?php echo $website; ?> &copy; 2016 Designed by Soxpress. All rights reserved.
                        </div>
                    </div>
                </div>
            </div>
            <!-- sub footer close -->

        </footer>
        <!-- footer close -->   
    </div>

    <a id="to-the-top" ><i class="fa fa-angle-up"></i></a>

    <!-- LOAD JS FILES -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script type="text/javascript" src="js/easing.js"></script>
    <script type="text/javascript" src="js/owl.carousel.js"></script>
    <script type="text/javascript" src="js/jquery.fitvids.js"></script>    
    <script type="text/javascript" src="js/wow.min.js"></script>
    <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>

    <!-- Waypoints-->
    <script type="text/javascript" src="js/jquery.waypoints.min.js"></script>
    <script type="text/javascript" src="js/sticky.min.js"></script>

    <script src="js/compact.js"></script> 
</body>
</html>
